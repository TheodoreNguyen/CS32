#include "StudentWorld.h"
#include <string>
using namespace std;
#include "Level.h"
#include <sstream>
#include <vector>
#include "GameConstants.h"
#include "Actor.h"
#include "GraphObject.h"
GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::~StudentWorld()
{
	cleanUp();
}

bool StudentWorld::canIMoveThere(int x, int y)
{

	for (int i = 0; i != numActors(); i++)
	{
		if (x == m_actors[i]->getX() && y == m_actors[i]->getY())
		if (m_actors[i]->isVisible())
			if (!m_actors[i]->getCollide())
				return false;
	}
	if (m_player->getX() == x && m_player->getY() == y)
		return false;
	return true;
}

void StudentWorld::updateDisplayText()
{
	int score = getScore();
	int level = getLevel();
	unsigned int bonus = m_player->getBonus();
	int livesLeft = getLives();

	int scoreSize = 0;
	if (score >= 0 && score <= 9)
		scoreSize = 1;
	else if (score >= 10 && score <= 99)
		scoreSize = 2;
	else if (score >= 100 && score <= 999)
		scoreSize = 3;
	else if (score >= 1000 && score <= 9999)
		scoreSize = 4;
	else if (score >= 10000 && score <= 99999)
		scoreSize = 5;
	else if (score >= 100000 && score <= 999999)
		scoreSize = 6;
	else if (score >= 1000000)
		scoreSize = 7;
	ostringstream ssscore;
	switch (scoreSize)
	{
	case 1:
		ssscore << "000000" << score;
		break;
	case 2:
		ssscore << "00000" << score;
		break;
	case 3:
		ssscore << "0000" << score;
		break;
	case 4:
		ssscore << "000" << score;
		break;
	case 5:
		ssscore << "00" << score;
		break;
	case 6:
		ssscore << "0" << score;
		break;
	case 7:
		if (score > 9999999)
			score = 9999999;
		ssscore << score;
		break;
	default: 

		break;
	}
	ostringstream sslevel;
	if (level >= 0 && level <= 9)
		sslevel << "0" << level;
	else if (level >= 10 && level <= 99)
		sslevel << level;
	else if (level > 99)
		return;

	ostringstream oss;
	oss << "Score: " << ssscore.str() << " Level: " << sslevel.str()
		<< " Lives: " << getLives() << " Health: " << m_player->getHpPercentage()
		<< "% Ammo: " << m_player->getAmmo() << " Bonus: " << m_player->getBonus();

	string s = oss.str();
	setGameStatText(s);

}

bool StudentWorld::gameFinished()
{
	if (m_player->levelFinished())
		return true;
	return false;
}

void StudentWorld::pushBackBullet(int startX, int startY, StudentWorld* wp, GraphObject::Direction dir)
{
	StudentWorld::m_actors.push_back(new Bullet(startX, startY, wp, dir));
	m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);

}

void StudentWorld::vectorEraser(int index)
{
	m_actors.erase(m_actors.begin() + index);
}

int StudentWorld::init()
{
	int numjewels = 0;
	Level lev(assetDirectory());
	ostringstream oss;
	if (m_level >= 0 && m_level <= 9)
		oss << "level0" << m_level << ".dat";
	else if (m_level >= 10 && m_level <= 99)
		oss << "level" << m_level << ".dat";
	else
		return GWSTATUS_PLAYER_WON; //okay
	string levelname = oss.str();
	Level::LoadResult result = lev.loadLevel(levelname);
	if (result == Level::load_fail_file_not_found)
		return GWSTATUS_PLAYER_WON;						//cerr << "Could not find level00.dat data file\n";
	else if (result == Level::load_fail_bad_format)
		return GWSTATUS_LEVEL_ERROR;
	else if (result == Level::load_success)
	{
		for (int x = 0; x != VIEW_WIDTH; x++)
		{
			for (int y = 0; y != VIEW_HEIGHT; y++)
			{
				Level::MazeEntry ge = lev.getContentsOf(x, y);
				switch (ge)
				{
				case Level::player:
					m_player = new Player(x, y, this);
					m_player->GraphObject::setVisible(true);
					//StudentWorld::m_actors.push_back(m_player);
					break;
				case Level::wall:
					StudentWorld::m_actors.push_back(new Wall(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::exit:
					m_exit = new Exit(x, y, this);
					m_exit->GraphObject::setVisible(false);
					//StudentWorld::m_actors.push_back(new Exit(x, y, this));
					//m_actors[m_actors.size() - 1]->GraphObject::setVisible(false);
					break;
				case Level::jewel:
					StudentWorld::m_actors.push_back(new Jewel(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					numjewels++;
					break;
				case Level::ammo:
					StudentWorld::m_actors.push_back(new AmmoGoodie(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::restore_health:
					StudentWorld::m_actors.push_back(new RestoreHealthGoodie(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::extra_life:
					StudentWorld::m_actors.push_back(new ExtraLifeGoodie(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::boulder:
					StudentWorld::m_actors.push_back(new Boulder(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::horiz_snarlbot:
					StudentWorld::m_actors.push_back(new SnarlBot(x, y, GraphObject::right, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::vert_snarlbot:
					StudentWorld::m_actors.push_back(new SnarlBot(x, y, GraphObject::down, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::hole:
					StudentWorld::m_actors.push_back(new Hole(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				case Level::kleptobot_factory:
					StudentWorld::m_actors.push_back(new KleptoBotFactory(x, y, this));
					m_actors[m_actors.size() - 1]->GraphObject::setVisible(true);
					break;
				default:
					break;
				}
			}
		}
	}
	if (numjewels != 0)
		m_player->setJewels(numjewels);
	else
		m_player->setJewels(-1);
	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	updateDisplayText();

	m_player->doSomething();
	m_exit->doSomething();
	//vector<Actor*>::iterator p = m_actors.begin();		5 bucks thats the crash - thats the crash but idk why
	for (int i = 0; i != m_actors.size(); i++)
	{
		if (m_actors[i]->isVisible())
			m_actors[i]->doSomething();

		if (!(m_player->alive()))
		{
			GameWorld::playSound(SOUND_PLAYER_DIE);
			decLives();
			//delete m_player;						//does not crash uner this command
			return GWSTATUS_PLAYER_DIED;
		}
		if (gameFinished())
		{
			m_level++;
			playSound(SOUND_FINISHED_LEVEL);
			return GWSTATUS_FINISHED_LEVEL;
		}
	}

	//remove dead actors after each tick
		//do this by checking if the actor is of type agent, then checking if it is dead or alive, then setting invisible

	for (int i = 0; i != m_actors.size(); i++)
	{
		Actor* ptr = m_actors[i];
		if (int(m_actors[i]->getActorType()) == IID_BOULDER || 
			int(m_actors[i]->getActorType()) == IID_HOLE ||
			int(m_actors[i]->getActorType()) == IID_ANGRY_KLEPTOBOT ||
			int(m_actors[i]->getActorType()) == IID_KLEPTOBOT ||
			int(m_actors[i]->getActorType()) == IID_SNARLBOT)
			if (!(m_actors[i]->isVisible()))
			{
				delete m_actors[i];
				m_actors.erase(m_actors.begin() + i);
			}
	}

	m_player->reduceBonus();

	if (m_player->jewelsLeft() == -1)
	{
		m_exit->setVisible(true);
	}
	if (!(m_player->alive()))
	{
		GameWorld::playSound(SOUND_PLAYER_DIE);
		decLives();
		//delete m_player;						//does not crash uner this command
		return GWSTATUS_PLAYER_DIED;
	}

	if (gameFinished())
		return GWSTATUS_FINISHED_LEVEL;

	return GWSTATUS_CONTINUE_GAME;
}
											//i was trying to implement cleanup and the destructr
void StudentWorld::cleanUp()
{
	vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		(*p)->GraphObject::setVisible(false);
		delete (*p);
		p = m_actors.erase(p);
	}
	m_player->GraphObject::setVisible(false);
	delete m_player;
	m_exit->GraphObject::setVisible(false);
	delete m_exit;
}
/*
int StudentWorld::Levelfcn(int lvl)
{
	Level lev(assetDirectory());
	ostringstream oss;
	if (lvl >= 0 && lvl <= 9)
		oss << "level0" << lvl << ".dat";
	else if (lvl >= 10 && lvl <= 99)
		oss << "level" << lvl << ".dat";
	else
		return 14;	
	string levelname = oss.str();
	Level::LoadResult result = lev.loadLevel(levelname);
	if (result == Level::load_fail_file_not_found)
		return 15;						//cerr << "Could not find level00.dat data file\n";
	else if (result == Level::load_fail_bad_format)
		return 16;						// cerr << "Your level was improperly formatted\n";
	else if (result == Level::load_success)
	{
		for (int x = 0; x != VIEW_WIDTH; x++)
		{
			for (int y = 0; y != VIEW_HEIGHT; y++)
			{
				Level::MazeEntry ge = lev.getContentsOf(x, y);
				switch (ge)
				{
				case Level::player:
					StudentWorld::m_actors.push_back(new Actor(IID_PLAYER, x, y, GraphObject::right, this));
					break;
				case Level::wall:
					StudentWorld::m_actors.push_back(new Actor(IID_WALL, x, y, GraphObject::none, this));
					break;
				default:
					break;
				}
			}
		}
	}
	return 0;
}*/